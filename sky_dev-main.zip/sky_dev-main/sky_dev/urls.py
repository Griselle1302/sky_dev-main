"""
URL configuration for sky_dev project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

# author griselle fernandes
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # for admin 
    path('admin/', admin.site.urls),
    # for health check 
    path('', include('health_check.urls')), #check health check urls
    # for account 
    path('accounts/', include('accounts.urls')), #check account urls
    # for team leader 
    path('teamleader/', include('teamleader.urls')),
    # for department leader 
    path('departmentleader/', include('departmentleader.urls')),
    # for administrator 
    path('administrator/', include('administrator.urls')),
    # for health check
    path('health/', include('health_check.urls')), 
]
